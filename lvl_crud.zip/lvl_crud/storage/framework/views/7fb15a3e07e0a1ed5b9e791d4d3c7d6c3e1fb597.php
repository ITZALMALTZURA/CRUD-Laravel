

<?php $__env->startSection('content'); ?>
<div class="container py-5 text-center">

    <?php if(isset($client)): ?>  
    <h1 class="text-center">Editar cliente</h1>
    <?php else: ?>
    <h1 class="text-center">Crear cliente</h1>
       
    <?php endif; ?>


    <?php if(isset($client)): ?>
    <form action="<?php echo e(route('client.update', $client)); ?>" method="post">
        <?php echo method_field('PUT'); ?>
    <?php else: ?>
    <form action="<?php echo e(route('client.store')); ?>" method="post">
    <?php endif; ?>

            <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Nombre</label>
                    <input type="text" name="name" class="form-control" placeholder="Nombre del cliente" value="<?php echo e(old('name') ?? @$client->name); ?>">
                    <p class="form-text">Escriba el nombre del cliente</p>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-text text-danger"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="due" class="form-label">Saldo</label>
                    <input type="number" name="due" class="form-control" placeholder="Nombre del cliente" step="0.01" value="<?php echo e(old('due') ?? @$client->due); ?>">
                    <p class="form-text">Escriba el saldo del cliente</p>
                    <?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-text text-danger"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="comments" class="form-label">Comentarios</label>
                    <textarea name="comments" cols="30" rows="4" class="form-control"><?php echo e(old('comments') ?? @$client->comments); ?></textarea>
                    <p class="form-text">Escriba algunos comentarios</p>
                    <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-text text-danger"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if(isset($client)): ?>
                <button type="submit" class="btn btn-info">Actualizar cliente</button>
                <?php else: ?>
                <button type="submit" class="btn btn-info">Guardar cliente</button>
                <?php endif; ?>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvl_crud\resources\views/client/form.blade.php ENDPATH**/ ?>