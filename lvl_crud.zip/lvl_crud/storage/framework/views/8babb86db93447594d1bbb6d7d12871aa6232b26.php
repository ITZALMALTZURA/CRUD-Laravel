<?php $__env->startSection('content'); ?>
<div class="container py-5 text-center">
    <h1 class="text-center">Hola Mundo!</h1>
    <a href="<?php echo e(route('client.index')); ?>" class="btn btn-primary">Clientes</a>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvl_crud\resources\views/welcome.blade.php ENDPATH**/ ?>