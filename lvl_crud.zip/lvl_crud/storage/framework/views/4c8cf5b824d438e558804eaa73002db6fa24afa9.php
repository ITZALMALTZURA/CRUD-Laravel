

<?php $__env->startSection('content'); ?>
<div class="container py-5 text-center">
    <h1 class="text-center">Listado de clientes</h1>
    <a href="<?php echo e(route('client.create')); ?>" class="btn btn-primary">Nuevo Cliente</a>

        <?php if(Session::has('mensaje')): ?>
            <div class="alert-info my-5">
                <?php echo e(Session::get('mensaje')); ?>

            </div>

        <?php endif; ?>
    <table class="table">
        <thead>
            <td>Nombre</td>
            <td>Saldo</td>
            <td>Acciones</td>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>
                <td><?php echo e($detail->name); ?></td>
                <td><?php echo e($detail->due); ?></td>
                <td>
                    <a href="<?php echo e(route('client.edit',$detail)); ?>" class="btn btn-warning">Edit</a>

                    <form action="<?php echo e(route('client.destroy', $detail)); ?>" method="POST" class="d-inline">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Estas seguro de eliminar a este cliente')">Eliminar</button>
                    </form>
                </td>
            </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3">No hay registros</td>
            </tr> 
            <?php endif; ?>
            
        </tbody>
    </table>
    <?php if($clients->count()): ?>
            <?php echo e($clients->links()); ?>

    <?php endif; ?>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvl_crud\resources\views/client/index.blade.php ENDPATH**/ ?>